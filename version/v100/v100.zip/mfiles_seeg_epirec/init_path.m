function varargout=init_path(varargin)
% generate structure of volume: name, folder, full path
% Example: 
% input... Vin='c:\data\CT.nii'
% output...Vout.name='CT.nii'
%          Vout.dir='c:\data'
%          Vout.path='c:\data\CT.nii'


varargout=cell(1,nargout);
for v=1:nargout
    if isempty(varargin{v}) % prázné pole
        varargout{v}=[];
    else
        for i=1:length(varargin{v})
            if isempty(varargin{v}(i).path) % prázdná cesta k souboru              
                continue
            end
            
            varargout{v}(1,i).path=varargin{v}(1,i).path;
            fsep=[strfind(varargin{v}(1,i).path,'/') strfind(varargin{v}(1,i).path,'\')];
            if isempty(fsep); fdir=pwd; else; fdir=varargin{v}(1,i).path(1:max(fsep)) ;end
            if isempty(fsep); fname=varargin{v}(1,i).path; else; fname=varargin{v}(1,i).path(max(fsep)+1:end) ;end
            varargout{v}(1,i).dir=fdir;
            varargout{v}(1,i).name=fname;
        end
    end
    
end
