%% SEEG contact detection
% SPM12 toolbox required https://www.fil.ion.ucl.ac.uk/spm/

clc; close all; clear all;

% Reqiuired: ==============================================================
CTE.path=fullfile(pwd,'raw_data','603553_CT.nii'); % path to postimplantation with electrodes (CT-E) 
MR.path=fullfile(pwd,'raw_data','603553_T1KL.nii'); % path to MRI for tissue segmentation (isotropic T1 recommended)

% Optional:
% CTL=[]; % not used
CTL.path=fullfile(pwd,'raw_data','603553_CTNAV.nii'); % path to preimplantaion CT for automatic masking of metal implants(frame, PET-CT(AC))
% =========================================================================


%% Initialization
% SPM12 toolbox check------------------------------------------------
spm_dir=what('spm12');
if isempty(spm_dir); error('SPM12 toolbox required'); end
% add toolbox path
addpath(fullfile(pwd,'mfiles_seeg_epirec'));

% path structures of volumes -----------------------------------------
[CTE, MR, CTL]=init_path(CTE,MR,CTL);

%% Image coregistration
% Skip if images are corregistred.
% The coregistration does not use reslicing, only change the orientation
% matrix. The referential image is MR, CTs originator is set to middle of volume and corregistered to MR 

originator_reset_v2([CTE CTL]); % originator reset

% coregistration: CT is thresholded in HU:10-2000(bone) to remove metal, corregistered to MR and applied on original CT
vol_coregistration_simple(MR,[CTE CTL]);

%% Tissue segmentation
% gray matter (c1), white matter (c2), and cerebrospinal fluid (c3)
% Skip, if done.
vol_segment(MR)


%% Get electrode list
% The detecting algorithm requires information defined approximate orientation and length of electrodes.
% The coordinates are in RAS in mm, format composed of:
% LABEL: electrode name
% TG: (LAT|AP|VER)target point (r,a,s)
% ENT: (LAT|AP|VER)entry point (r,a,s)
% S: (S1|S2|S3)directional vector (sr,sa,ss)
% N contacts: number of contacts
% Order: implantation order
% Color: 'HEX' (not used)
%
% This information can be obtained from planning software using target
% (TG) and entry (ENT) points. S=(ENT-TG); S=S/sqrt(sum(S.^2));
% Unavailable TG and ENT coordinates can be set manually, e.g., in 3D Slicer
% and stored in *.fcsv list. The tutorial is attached to toolbox ("Tutorial - fiducials.pdf")

% Example using FCSV electrode definition
% NAVI=get_fcsv_trajectory(fullfile(pwd,'volume_data','SLICER','F.fcsv'),CTE); % E.g., 
NAVI=get_fcsv_trajectory('F.fcsv',CTE); % Add full-path to your fcsv file

%% Detect contacts and bone measurement


[ELECTRODES,BONE_MEASURE]=localize_seeg_contacts_v3(NAVI,CTL,CTE,MR);
% What do, when preimplantation CT (CTL) unexists or detection failed?
% The algorithm can not recognize metal implantation in CTE without comparison to CTL.
% Similarly, if another metal objects are inserted with SEEG to ROI of the
% head, algorithm assignes them to one of electrode and distord its
% approximation. The manual masking volume is required! See "Tutorial".

% masking=fullfile(pwd,'volume_data','603553_CT-label.nii');
% [ELECTRODES]=localize_seeg_contacts_v3(NAVI,[],CTE,MR,masking); % CTL=[];


%% Measurement in planning process
% When you have planned trajectories (entry and target points), you can
% mesure bone thickness, implantation angle and intracerebral depth using
% pre-implantation CT (CT-L). Example of planning export trajectories is in
% "navi_plan_native.csv".

NAVI=readtable('navi_plan_native.csv'); % E.g.
% NAVI=readtable(fullfile(pwd,'volume_data','navi_plan_native.csv')); % E.g.
NAVI=NAVI(:,1:7); % Name, Target point, Entry point
[~,BONE_MEASURE_palnning]=localize_seeg_contacts_v3(NAVI,CTL,[],MR);
