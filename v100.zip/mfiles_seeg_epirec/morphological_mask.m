function [MASK,R]=morphological_mask(c_size,vox_size,mode,sigma)
% c_size v mm

if nargin<3
    mode='ball';
end


if mod(floor(c_size/vox_size(2)),2)==0; c2=1; else c2=0; end
if mod(floor(c_size/vox_size(1)),2)==0; c1=1; else c1=0; end
if mod(floor(c_size/vox_size(3)),2)==0; c3=1; else c3=0; end

[Y,X,Z]=meshgrid(   linspace(-c_size/2,c_size/2,c_size/vox_size(2)+c2),...
                    linspace(-c_size/2,c_size/2,c_size/vox_size(1)+c1),...
                    linspace(-c_size/2,c_size/2,c_size/vox_size(3)+c3));
                
% switch
switch mode
    case 'ball'
        R=sqrt(X.^2+Y.^2+Z.^2);
        MASK=R<=c_size/2;
    case 'gauss'
        MU=[0,0,0];
        SIGMA=eye(3)*sigma./vox_size;
        f= @(x,y,z,mu,sigma) (1/sqrt((2*pi)^3*det(sigma)))*exp(-( ((x-mu(1))/sigma(1,1)).^2+((y-mu(2))/sigma(2,2)).^2 + ((z-mu(3))/sigma(3,3)).^2 )/2);
        MASK=f(X,Y,Z,MU,SIGMA);
        MASK=MASK/max(MASK(:));
        
        R=sqrt(X.^2+Y.^2+Z.^2);
end