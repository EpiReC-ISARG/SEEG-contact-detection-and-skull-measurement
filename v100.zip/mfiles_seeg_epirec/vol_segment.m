function vol_segment(infiles,gmngaus)

if nargin<2
    gmngaus=1; % for GM, WM
end

files2segment=[];

if iscell(infiles)
    for i=1:length(infiles)
        for j=1:length(infiles{i});
            
            files2segment=[files2segment; {infiles{i}(j).path}];
        end
    end
elseif isstruct(infiles)
    files2segment=arrayfun(@(x) x.path,infiles,'UniformOutput',0);
end



spm_dir=what('spm12');
if isempty(spm_dir); error('SPM12 toolbox required'); end
spm_dir=spm_dir.path;


disp('')
disp('------------------------------------------------')
disp('BRAIN TISUE SEGMENTATION')
disp('------------------------------------------------')
disp(files2segment(:))
disp('')

close all
ifig = spm('CreateIntWin','on');
gfig = spm_figure('Create','Graphics'); set(gfig,'Visible','off')

matlabbatch={};
matlabbatch{1}.spm.spatial.preproc.channel.vols =files2segment(:);
matlabbatch{1}.spm.spatial.preproc.channel.biasreg = 0.1;
matlabbatch{1}.spm.spatial.preproc.channel.biasfwhm = 40;
matlabbatch{1}.spm.spatial.preproc.channel.write = [0 0];
matlabbatch{1}.spm.spatial.preproc.tissue(1).tpm = {fullfile(spm_dir,'tpm','TPM.nii,1')};
matlabbatch{1}.spm.spatial.preproc.tissue(1).ngaus = gmngaus;
matlabbatch{1}.spm.spatial.preproc.tissue(1).native = [1 0];
matlabbatch{1}.spm.spatial.preproc.tissue(1).warped = [0 0];
matlabbatch{1}.spm.spatial.preproc.tissue(2).tpm = {fullfile(spm_dir,'tpm','TPM.nii,2')};
matlabbatch{1}.spm.spatial.preproc.tissue(2).ngaus = 1;
matlabbatch{1}.spm.spatial.preproc.tissue(2).native = [1 0];
matlabbatch{1}.spm.spatial.preproc.tissue(2).warped = [0 0];
matlabbatch{1}.spm.spatial.preproc.tissue(3).tpm = {fullfile(spm_dir,'tpm','TPM.nii,3')};
matlabbatch{1}.spm.spatial.preproc.tissue(3).ngaus = 2;
matlabbatch{1}.spm.spatial.preproc.tissue(3).native = [1 0];
matlabbatch{1}.spm.spatial.preproc.tissue(3).warped = [0 0];
matlabbatch{1}.spm.spatial.preproc.tissue(4).tpm = {fullfile(spm_dir,'tpm','TPM.nii,4')};
matlabbatch{1}.spm.spatial.preproc.tissue(4).ngaus = 3;
matlabbatch{1}.spm.spatial.preproc.tissue(4).native = [1 0];
matlabbatch{1}.spm.spatial.preproc.tissue(4).warped = [0 0];
matlabbatch{1}.spm.spatial.preproc.tissue(5).tpm = {fullfile(spm_dir,'tpm','TPM.nii,5')};
matlabbatch{1}.spm.spatial.preproc.tissue(5).ngaus = 4;
matlabbatch{1}.spm.spatial.preproc.tissue(5).native = [0 0];
matlabbatch{1}.spm.spatial.preproc.tissue(5).warped = [0 0];
matlabbatch{1}.spm.spatial.preproc.tissue(6).tpm = {fullfile(spm_dir,'tpm','TPM.nii,6')};
matlabbatch{1}.spm.spatial.preproc.tissue(6).ngaus = 2;
matlabbatch{1}.spm.spatial.preproc.tissue(6).native = [0 0];
matlabbatch{1}.spm.spatial.preproc.tissue(6).warped = [0 0];
matlabbatch{1}.spm.spatial.preproc.warp.mrf = 1;
matlabbatch{1}.spm.spatial.preproc.warp.cleanup = 2;
matlabbatch{1}.spm.spatial.preproc.warp.reg = [0 0.001 0.5 0.05 0.2];
matlabbatch{1}.spm.spatial.preproc.warp.affreg = 'mni';
matlabbatch{1}.spm.spatial.preproc.warp.fwhm = 0;
matlabbatch{1}.spm.spatial.preproc.warp.samp = 2;
% matlabbatch{1}.spm.spatial.preproc.warp.write = [1 1]; % 'iy_* y_*' [inverse forward] neodpov�d� SPM normalise, asi bug
matlabbatch{1}.spm.spatial.preproc.warp.write = [1 0]; % 'iy_* y_*' [inverse forward]

off2=length(matlabbatch);
spm_jobman('run',matlabbatch);
try
    close(ifig)
end