function TAB=get_fcsv_trajectory(fcsv_path,CTE)
contact_L=2; % cilinder length mm
contact_G=1.5; % space mm


T=readtable(fcsv_path,'FileType','text','Delimiter',',','PreserveVariableNames',1);

% get unique prefix
pref=cellfun(@(x) x((double(x)>=65 & double(x)<=90) | (double(x)>=97 & double(x)<=122)),T.label,'UniformOutput',0);
suf=cellfun(@(x) str2double(x(double(x)>=48 & double(x)<=57)),T.label,'UniformOutput',1);

[C,ai]=unique(pref);
[~,ai]=sort(ai);
unq_pref=C(ai);

TAB=table('Size',[length(unq_pref) 13],'VariableTypes',['cell' repmat({'double'},[1 11]) 'cell']);
TAB.Properties.VariableNames={'Name','TG: LAT','TG: AP','TG: VER','ENT: LAT','ENT: AP','ENT: VER',...
    'S1','S2','S3','N contacts','Order','Color'};

cte_stack=true; % load CT-E, if required

% for each electrode
for el=1:length(unq_pref)
    TAB.Name(el)=unq_pref(el);
    
    
    ridx=cellfun(@(x) strcmp(x,unq_pref{el}),pref);
    TS=T(ridx,:);
    % ascend in list
    [~,s]=sort(suf(ridx));
    TS=TS(s,:);
    
    
    if size(TS,1)==1 % if contain only entry point, estimate direction using CT-E
        tol=10; %+/-mm
        
        % CT-E loading
        if cte_stack
            cte=spm_vol(CTE.path);
            IT=spm_imatrix(cte.mat);
%             orig=IT(1:3);
            vox_size=abs(IT(7:9));
            VCTE=spm_read_vols(cte);
            cte_stack=false;
            f1=figure();
            disp('Direction estimation by the anchor bolt:')
        end
        
        
        ENTras=[TS.x TS.y TS.z];
        ijk=round(inv(cte.mat)*[ENTras 1]');
        
        imin=round(ijk(1)-tol/vox_size(1)); imin(imin<1)=1;
        imax=round(ijk(1)+tol/vox_size(1)); imax(imax>size(VCTE,1))=size(VCTE,1);
        jmin=round(ijk(2)-tol/vox_size(2)); jmin(jmin<1)=1;
        jmax=round(ijk(2)+tol/vox_size(2)); jmax(jmax>size(VCTE,2))=size(VCTE,2);
        kmin=round(ijk(3)-tol/vox_size(3)); kmin(kmin<1)=1;
        kmax=round(ijk(3)+tol/vox_size(3)); kmax(kmax>size(VCTE,3))=size(VCTE,3);
        
        [J,I,K]=meshgrid(jmin:jmax,imin:imax,kmin:kmax);
        R=sqrt(((I-ijk(1))*vox_size(1)).^2 + ((J-ijk(2))*vox_size(2)).^2 + ((K-ijk(3))*vox_size(3)).^2); % distance from fidutial (weight)
%         W=1./R; W(W>1)=1;
        subV=VCTE(imin:imax,jmin:jmax,kmin:kmax);
        
        idx=find(subV>3000 & R<=10);
        [I1,I2,I3]=ind2sub(size(subV),idx);
        GMModel = fitgmdist([I1 I2 I3],1);
        [~,D,W]=eig(GMModel.Sigma);
        [~,maxE]=max(D(logical(eye(3))));
        
        s1=-tol*W(:,maxE)+GMModel.mu(:);
        s2=+tol*W(:,maxE)+GMModel.mu(:);
        
        s1ras=cte.mat*[s1(:); 1];
        s2ras=cte.mat*[s2(:); 1];
        sras=s2ras-s1ras; sras=sras(1:3)./sqrt(sum(sras(1:3).^2)); % directorial normalized vector in RAS
        
        el_L=str2double(TS.label{1}(double(TS.label{1})>=48 & double(TS.label{1})<=57));
        el_L=contact_L*el_L+contact_G*(el_L-1);
        
        % direction to CT-E originator
        TGras(:,1)=ENTras(:)+sras(:)*el_L;
        TGras(:,2)=ENTras(:)-sras(:)*el_L;
        
        D=sqrt(sum((TGras-[0;0;0]).^2));
        [~,pozm]=min(D);
        TGras=TGras(:,pozm);
        
        TAB{el,2:7}=[TGras(:)' ENTras(:)'];
        S=ENTras(:)-TGras(:); % ENT-TG
        S=S./sqrt(sum(S.^2)); % normalized directional vector
        TAB{el,8:10}=S';
        
        figure(f1);
        subplot(ceil(length(unq_pref)/5),5,el);
        isosurface(subV>3000 & R<=tol); alpha(0.5); view(45,45); title(['Anchor bolt ' unq_pref(el)])
        hold on
        plot3([s1(2) s2(2)],[s1(1) s2(1)],[s1(3) s2(3)],'r')
        disp([unq_pref{el} ': done'])
    else
        TAB{el,2:7}=[TS.x(1) TS.y(1) TS.z(1) TS.x(2) TS.y(2) TS.z(2)];
        S=[TS.x(2) TS.y(2) TS.z(2)]-[TS.x(1) TS.y(1) TS.z(1)]; % ENT-TG
        S=S./sqrt(sum(S.^2)); % normalized directional vector
        TAB{el,8:10}=S;
    end
    TAB{el,11}=max(suf(ridx)); % nuber of contacts
    TAB{el,12}=el;
    TAB{el,13}={''};
end