function vol_corregistration_simple(RF,CT,OTHER)
% INPUTS: as struct X.path, X.dir, X.name
%         or cells with path {'T2.nii','T1.nii'}
%         var1... fixed volume
%         var2, var3... moving volumes


try
    ifig = spm('CreateIntWin','on');
    gfig = spm_figure('Create','Graphics'); set(gfig,'Visible','off')
end

if exist('OTHER','var')==0
    OTHER=[];
end

if exist('PET','var')==0
    PET=[];
end




RF=stringpath2struct(RF);
CT=stringpath2struct(CT);
OTHER=stringpath2struct(OTHER); 
PET=stringpath2struct(PET); 



off=0;
if ~isempty(CT)
%     if ~isempty(CT.path)
    if sum(arrayfun(@(x) ~isempty(x.path),CT))>0
        CT=CT(arrayfun(@(x) ~isempty(x.path),CT));
        
        for i=1:length(CT)
            if i==1
                % ct masking
                VI=spm_vol(CT(i).path);
                VO=VI; VO.fname=[CT(i).dir, 'm', CT(i).name];
                f='i1.*(i1<2000).*(i1>10)';
                                
                VO = spm_create_vol(VO);    
                VO = spm_imcalc(VI,VO,f);
                
                
                matlabbatch=[];
                matlabbatch{off+i}.spm.spatial.coreg.estimate.ref = {RF.path};
                matlabbatch{off+i}.spm.spatial.coreg.estimate.source = {[CT(i).dir, 'm', CT(i).name]};
                matlabbatch{off+i}.spm.spatial.coreg.estimate.other = {CT(i).path;[CT(i).dir, 'm', CT(i).name]};
                matlabbatch{off+i}.spm.spatial.coreg.estimate.eoptions.cost_fun = 'nmi';
                matlabbatch{off+i}.spm.spatial.coreg.estimate.eoptions.sep = [4 2]; % [4 2] default
                matlabbatch{off+i}.spm.spatial.coreg.estimate.eoptions.tol = [0.02 0.02 0.02 0.001 0.001 0.001 0.01 0.01 0.01 0.001 0.001 0.001];
                matlabbatch{off+i}.spm.spatial.coreg.estimate.eoptions.fwhm = [7 7]; % [7 7] default
            else
                fprintf(2,[CT(i).name ' will be corregistered to ' CT(1).name '\n'])
                matlabbatch{off+i}.spm.spatial.coreg.estimate.ref = {[CT(1).dir, 'm', CT(1).name]};
                matlabbatch{off+i}.spm.spatial.coreg.estimate.source = {[CT(i).path]};
                matlabbatch{off+i}.spm.spatial.coreg.estimate.other = {''};
                matlabbatch{off+i}.spm.spatial.coreg.estimate.eoptions.cost_fun = 'nmi';
                matlabbatch{off+i}.spm.spatial.coreg.estimate.eoptions.sep = [4 2]; % [4 2] default
                matlabbatch{off+i}.spm.spatial.coreg.estimate.eoptions.tol = [0.02 0.02 0.02 0.001 0.001 0.001 0.01 0.01 0.01 0.001 0.001 0.001];
                matlabbatch{off+i}.spm.spatial.coreg.estimate.eoptions.fwhm = [7 7]; % [7 7] default
            end
        end
        off=length(matlabbatch);
    end
end


if ~isempty(OTHER)
    if sum(arrayfun(@(x) ~isempty(x.path),OTHER))>0
        OTHER=OTHER(arrayfun(@(x) ~isempty(x.path),OTHER));
        
        for i=1:length(OTHER)
            matlabbatch{off+i}.spm.spatial.coreg.estimate.ref = {RF.path};
            matlabbatch{off+i}.spm.spatial.coreg.estimate.source = {OTHER(i).path};
            matlabbatch{off+i}.spm.spatial.coreg.estimate.eoptions.cost_fun = 'nmi';
            matlabbatch{off+i}.spm.spatial.coreg.estimate.eoptions.sep = [4 2]; % [4 2] default
            matlabbatch{off+i}.spm.spatial.coreg.estimate.eoptions.tol = [0.02 0.02 0.02 0.001 0.001 0.001 0.01 0.01 0.01 0.001 0.001 0.001];
            matlabbatch{off+i}.spm.spatial.coreg.estimate.eoptions.fwhm = [7 7]; % [7 7] default
        end
        off=length(matlabbatch);
    end
end


% RUN Jobs
% length(matlabbatch)
spm_jobman('run',matlabbatch(1:off));
try
    set(gfig,'Visible','on')
end
try
    close(ifig)
end

check_list=[];
check_list.path=RF.path;
check_list.dir=RF.dir;

if ~isempty(CT)
    if sum(arrayfun(@(x) ~isempty(x.path),CT))>0
        CT=CT(arrayfun(@(x) ~isempty(x.path),CT));
        for i=1:length(CT)
            if i==1
                check_list(length(check_list)+1).path=[CT(i).dir, 'm', CT(i).name];
                check_list(length(check_list)).dir=[CT(i).dir];
            end
            check_list(length(check_list)+1).path=[CT(i).dir, CT(i).name];
            check_list(length(check_list)).dir=[CT(i).dir];
        end
    end
end

if ~isempty(OTHER)
    if sum(arrayfun(@(x) ~isempty(x.path),OTHER))>0
        OTHER=OTHER(arrayfun(@(x) ~isempty(x.path),OTHER));
        for i=1:length(OTHER)
            check_list(length(check_list)+1).path=OTHER(i).path;
            check_list(length(check_list)).dir=OTHER(i).dir;
        end
    end
end


spm_check_registration(check_list.path)
 

% ----------------------------------------------------
% rewritte both transform matrices (e.g., Slicer uses provate.mat0, SPM edits only .mat) 
for i=1:length(check_list)
    V=spm_vol(check_list(i).path);
    if sum(sum(abs(V.mat-V.private.mat0)))>1e-3
        V.private.mat0=V.mat;
        V=spm_create_vol(V);
    end
end



if nargin>=5
    if no_zip; return; end
end    

for i=1:length(check_list)
    gzip(fullfile(check_list(i).path),fullfile(check_list(i).dir,'SLICER'));
end
end






function OUT=stringpath2struct(IN)

if iscell(IN) || ischar(IN)
    if ischar(IN); IN={IN}; end
    
    NEWstruct=[];
    for i=1:length(IN)
        name=dir(IN{i});
        NEWstruct(i).path=fullfile(name.folder,name.name);
        NEWstruct(i).dir=[name.folder filesep];
        
        sidx=sort([strfind(name.name,'/') strfind(name.name,'\')]);
        if isempty(sidx)
            NEWstruct(i).name=name.name;
        else
            NEWstruct(i).name=name.name(sidx(end)+1:end);
        end
    end
    OUT=NEWstruct;
elseif isstruct(IN) || isempty(IN)
    OUT=IN;
else
    error('incorrect input (path or struct)')
end


end
