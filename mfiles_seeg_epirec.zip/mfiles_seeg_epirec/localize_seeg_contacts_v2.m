function [EL_SET,BONE_MEASURE]=localize_seeg_contacts_v2(navi,CTL,CTE,MR,CT_MASKING,poly_order)
% Detecting of SEEG contacts
% inputs:
%   navi... table of electrodes trajectories for initializing
%   CTL... preimplantation CT (CT-L, PET-CT) or []
%   CTE... CT with electrodes 
%   MR... MR to GM, WM, CSF segmentation (T1 recommended)
%   CT_MASKING... path to binary volume (*.nii), whiw mask the region
%                 excluding from detection (metal implantates)
%   poly_order... order of electrode approximation (default 3). If
%                electrodes are wavy, increase value. 
%                1x1 for all electrodes
%                size(navi,1)x1 specifies for each electrodes idividually
% outputs:
% EL_SET: cell of RAS coordinates of all contacts
% BONE_MEASURE: table of bone measurement

emptyNAV=false;
if isempty(CTL)
    CTL=CTE;
    emptyNAV=true;
end

emptyCTE=false;
if isempty(CTE)
    emptyCTE=true;
end

elset_path=fullfile(CTE.dir,'electrodes_auto.csv');
bone_path=fullfile(CTE.dir,'bone_measurement.csv');

if length(CTE)>1; CTE=CTE(1); warning([CTE(1).name ' was used as referential']); end


ct_th=3500;
el_dist=1.5; % mm
el_dim=2; % mm
el_ball=0.8; % mm

res=0.1; % mm computed precission



if length(MR)>1
    warning(['The first MR is used: ' MR(1).name])
    MR=MR(1);
end



EL=unique(navi{:,1}); % prefix of electrodes;
navi_unique={};
for i=1:length(EL)
    uidx=find(arrayfun(@(x) strcmp(EL{i,1},x),navi{:,1}));
    
    navi_unique(uidx(1),:)=table2cell(navi(uidx(1),:)); % [name TG ENT n_cont]
end
idx=cellfun(@(x) isempty(x),navi_unique(:,1));
navi_unique(idx,:)=[];
n_el=size(navi_unique,1); % number of electrodes

ct=spm_vol(CTE.path);
ctnav=spm_vol(CTL.path);
VCT=spm_read_vols(ct);
vox_size = spm_imatrix(ct.mat);
vox_size = abs(vox_size(7:9)); % get voxel size from CT

reslice=true;


% resliceing of CTNAV to CT space
if ~emptyNAV
    if reslice

        P = ct; % header of fis CT
        P(2) = ctnav; % header of navi CT
        spm_reslice(P,struct('mean',false,'which',1,'interp',1,'prefix','r'))
        rctnav=spm_vol(fullfile(CTL.dir,['r' CTL.name]));
    else
        fprintf(2,['Used existing ' ['r' CTL.name] '\n'])
    end
    VCTNAV=spm_read_vols(rctnav);
else
    VCTNAV=VCT;
end


% difference between navi CT and implat to masking metal particles
if ~emptyNAV
    METAL_CT=VCT>3000;
    METAL_NAV=VCTNAV>3000;
    [MASK,~] = morphological_mask(6, vox_size); % i.e. strel - ball
    METAL_NAV = dilateN(METAL_NAV>0.5, MASK); % dilation
    
    METAL_CT=METAL_NAV&METAL_CT;
    clear METAL_NAV;
else
    METAL_CT=zeros(size(VCT));
end


if exist('CT_MASKING','var')>0
    if ~isempty(CT_MASKING)
        ctmask=spm_vol(CT_MASKING);
        CTMASK=spm_read_vols(ctmask); CTMASK=CTMASK>0.5;
        VCT=VCT.*(~CTMASK).*(~METAL_CT);
        VCTNAV=VCTNAV.*(~CTMASK).*(~METAL_CT);
        clear CTMASK
    else
        VCT=VCT.*(~METAL_CT);
        VCTNAV=VCTNAV.*(~METAL_CT);
    end
else
    VCT=VCT.*(~METAL_CT);
    VCTNAV=VCTNAV.*(~METAL_CT);
end
clear METAL_CT;



cXfiles=dir(fullfile(MR.dir,['c*' MR.name]));
if isempty(cXfiles)
    vol_segment(MR)
    cXfiles=dir(fullfile(MR.dir,['c*' MR.name]));
end

% mask of intracranial space + lebka
disp('HEAD EXTRACTION ====================================================')
files=arrayfun(@(x) fullfile(x.folder,x.name),cXfiles,'UniformOutput',false);
matlabbatch={};
if ~emptyNAV
    matlabbatch{1}.spm.util.imcalc.input = [{fullfile(CTL.dir,['r' CTL.name])}; files(:)];
else
    matlabbatch{1}.spm.util.imcalc.input = [{CTL.path}; files(:)];
end
matlabbatch{1}.spm.util.imcalc.output = ['rintraT.nii'];
matlabbatch{1}.spm.util.imcalc.outdir = {CTL.dir};
matlabbatch{1}.spm.util.imcalc.expression = '(i2+i3+i4)>=0.5';
matlabbatch{1}.spm.util.imcalc.var = struct('name', {}, 'value', {});
matlabbatch{1}.spm.util.imcalc.options.dmtx = 0;
matlabbatch{1}.spm.util.imcalc.options.mask = 0;
matlabbatch{1}.spm.util.imcalc.options.interp = 1;
matlabbatch{1}.spm.util.imcalc.options.dtype = 2;
spm_jobman('run',matlabbatch(1));


% ROI of head ============================================================
cct=spm_vol(fullfile(CTL.dir,'rintraT.nii'));
VCCT=spm_read_vols(cct); % intracranial space
% delete(fullfile(CTNAV.dir,'rintraT.nii'));

% soft tisue from CT
VCCHEAD=(VCTNAV>-150) & (VCTNAV~=0) & (VCTNAV<2000) & (VCT>-150) & (VCT<2000);

% dilate intracranial space
[MASK,~] = morphological_mask(10, vox_size); % i.e. strel - ball
VCCT = dilateN(VCCT>0.5, MASK); % erossion

% clean CT tissue
% [MASK,~] = morphological_mask(3, vox_size); % i.e. strel - ball
% VCCHEAD = erodeN(VCCHEAD>0.5, MASK); % erossion
[MASK,~] = morphological_mask(7, vox_size); % i.e. strel - ball
VCCHEAD = dilateN(VCCHEAD>0.5, MASK); % dilation

[MASK,~] = morphological_mask(8, vox_size); % i.e. strel - ball
VCCHEAD = erodeN(erodeN(VCCHEAD>0.5, MASK),MASK); % 2x erossion

VCCT=VCCT | VCCHEAD; % merge MR a CT tisssue 

VC.fname=fullfile(CTE.dir,'rhead.nii');
VC.dim=size(VCCT);
VC.dt=[2 0]; 
VC.pinfo=[1 0 0]';
VC.mat=cct.mat;
VC=spm_create_vol(VC);
spm_write_vol(VC,VCCT);


disp('GMM ELECTRODE CLUSTERING ===========================================')
% map of trajectories ----------------------------------------------------
% dle TG a trajektorie odhadne poslední kontakt elektrody.
navi_ijk=zeros(n_el,6);
for el=1:n_el
    r=(navi_unique{el,11}-1)*el_dist+navi_unique{el,11}*el_dim;
    last_contact=cell2mat(navi_unique(el,2:4))+cell2mat(navi_unique(el,8:10))*r;
    
    RAS=[navi_unique{el,2:4} 1; last_contact 1];
    IJK=inv(ct.mat)*RAS';
    
    navi_ijk(el,:)=[IJK(1:3,1)' IJK(1:3,2)'];
    
%     hold on
%     plot3(IJK(2,:),IJK(1,:),IJK(3,:),'r')
%     text(IJK(2,end),IJK(1,end),IJK(3,end),EL{el})
end

% GMM (model trénovaní - gausián mezi prvním a posledním kontaktem - dle navigace)
S.mu = (navi_ijk(:,1:3)+navi_ijk(:,4:6))/2; % na cca prostřední kontakt
S.ComponentProportion = ones(1,size(navi_unique,1))/size(navi_unique,1);
S.Sigma = zeros([3 3 n_el]);
for el = 1:size(navi_unique,1)
    covariance = cov([navi_ijk(el,1:3); navi_ijk(el,4:6)]);
    epsilon = 0.01*max([covariance(1,1) covariance(2,2) covariance(3,3)]);
    S.Sigma(:,:,el) = covariance + epsilon*eye(3);
end


vidx=find((VCT.*VCCT)>ct_th);

VIJK=[];
[VIJK(:,1),VIJK(:,2),VIJK(:,3)]=ind2sub(size(VCT),vidx);

% train by intracranial space of CT
GMM = fitgmdist(VIJK, size(S.mu,1), 'RegularizationValue', 0.1, 'Start', S);


vidx=find((VCT.*VCCT)>ct_th);
VIJK=[];
[VIJK(:,1),VIJK(:,2),VIJK(:,3)]=ind2sub(size(VCT),vidx);
cidx=cluster(GMM,VIJK);



%% ROI
disp('CENTACTS LOCALIZATION =============================================')
fig0=figure(); fig0.WindowState='maximized'; pause(0.5);
fig1=figure(); fig1.WindowState='maximized'; pause(0.5);

isosurface(VCT>ct_th); alpha(0.5)
colormap('gray')
fig2=figure(); fig2.WindowState='maximized'; pause(0.5);
fig3=figure(); fig3.WindowState='maximized'; pause(0.5);

BONE_MEASURE=[];
if ~emptyNAV
    BONE_MEASURE=table('Size',[n_el 7],'VariableTypes',['cell' repmat({'double'},[1 3]) 'cell' 'cell' 'cell']);
    BONE_MEASURE.Properties.VariableNames={'Name','Bone thickness','Implant. angle','Depth from ENTintra','TIP','ENTextra','ENTintra'};
%     BONE_MEASURE.Name=navi.Name;
    fig4=figure(); fig4.WindowState='maximized'; pause(0.5)
    fig5=figure(); fig5.WindowState='maximized'; pause(0.5)
end

ecc=jet(n_el);
for el=1:n_el
    RAS=[navi_unique{el,2:4} 1; navi_unique{el,5:7} 1];
    IJK=inv(ct.mat)*RAS';
    figure(fig1); % subplot(224); 
    hold on
    plot3(IJK(2,:),IJK(1,:),IJK(3,:),'Color',0.8*ecc(el,:))
    text(IJK(2,2),IJK(1,2),IJK(3,2),navi_unique{el,1},'Color',0.8*ecc(el,:))
    
    figure(fig0); hold on
    plot3(VIJK(cidx==el,2),VIJK(cidx==el,1),VIJK(cidx==el,3),'.k','Color',0.8*ecc(el,:))
    plot3(IJK(2,:),IJK(1,:),IJK(3,:),'Color',0.8*ecc(el,:))
    text(IJK(2,2),IJK(1,2),IJK(3,2),navi_unique{el,1},'Color',0.8*ecc(el,:))
end

for el=1:n_el
    warning('off','curvefit:fit:equationBadlyConditioned')
    
    % trajectory tolerance
    delta=20; % mm extrapolation of electrode end

  
    % electrode direction in IJK -----------------------------------------
    RAS=[navi_unique{el,2:4} 1; navi_unique{el,5:7} 1];
    IJK=inv(ct.mat)*RAS';
    
    
    IJKvec=IJK(1:3,2)-IJK(1:3,1);
    IJKvec=IJKvec/sqrt(sum(IJKvec.^2)); % normalized directional vector
    
    % --------------------------------------------------------------------
    % GMM cluster mapping
    X=VIJK(cidx==el,1);
    Y=VIJK(cidx==el,2);
    Z=VIJK(cidx==el,3);

    % deltamax - axis of biggest electrode projection
    [~,deltamax]=max([max(X)-min(X) max(Y)-min(Y) max(Z)-min(Z)]);
    % 1 - leading variable x
    % 2 - leading variable y
    % 3 - leading variable z
    
    if exist('poly_order','var')==0
        order=3; % polynomial order of electrode approximation
    else
        if length(poly_order)==n_el
            order=poly_order(el);
        else
            order=poly_order;
        end
    end

    DIST=1;
    
    switch deltamax
        case 1
            pxy=fit(X,Y,['poly' num2str(order)],'weight',VCT(sub2ind(size(VCT),X,Y,Z)).*(1./DIST));
            pxz=fit(X,Z,['poly' num2str(order)],'weight',VCT(sub2ind(size(VCT),X,Y,Z)).*(1./DIST));
            
            % směr
            if IJKvec(1)<0
%                 XI=(min(X)-delta/vox_size(1):res:max(X))';
                XI=(min(X)-abs(delta*IJKvec(1)/vox_size(1)):res:max(X))';
            else
%                 XI=(min(X):res:max(X)+delta/vox_size(1))';
                XI=(min(X):res:max(X)+abs(delta*IJKvec(1)/vox_size(1)))';
            end
            YI = feval(pxy,XI);
            ZI = feval(pxz,XI);
            
            RES_EL(el).polyX={pxy;pxz};
        case 2
            pyx=fit(Y,X,['poly' num2str(order)],'weight',VCT(sub2ind(size(VCT),X,Y,Z)).*(1./DIST));
            pyz=fit(Y,Z,['poly' num2str(order)],'weight',VCT(sub2ind(size(VCT),X,Y,Z)).*(1./DIST));
            
            if IJKvec(2)<0
                YI=(min(Y)-abs(delta*IJKvec(2)/vox_size(2)):res:max(Y))';
            else
                YI=(min(Y):res:max(Y)+abs(delta*IJKvec(2)/vox_size(2)))';
            end
            XI = feval(pyx,YI);
            ZI = feval(pyz,YI);
            RES_EL(el).polyY={pyx;pyz};
            
        case 3
            pzx=fit(Z,X,['poly' num2str(order)],'weight',VCT(sub2ind(size(VCT),X,Y,Z)).*(1./DIST));
            pzy=fit(Z,Y,['poly' num2str(order)],'weight',VCT(sub2ind(size(VCT),X,Y,Z)).*(1./DIST));
            
            if IJKvec(3)<0
                ZI=(min(Z)-abs(delta*IJKvec(3)/vox_size(3)):res:max(Z))';
            else
                ZI=(min(Z):res:max(Z)+abs(delta*IJKvec(3)/vox_size(3)))';
            end
            XI = feval(pzx,ZI);
            YI = feval(pzy,ZI);
            RES_EL(el).polyZ={pzx;pzy};
    end
    idx=find(XI<0 | YI<0 | ZI<0 | XI>size(VCT,1) | YI>size(VCT,2) | ZI>size(VCT,3));
    XI(idx)=[]; YI(idx)=[]; ZI(idx)=[];  
    
    RES_EL(el).XI=XI; RES_EL(el).YI=YI; RES_EL(el).ZI=ZI; 
    
    DL=sqrt(diff(XI(:)*vox_size(1)).^2+diff(YI(:)*vox_size(2)).^2+diff(ZI(:)*vox_size(3)).^2);
    
    figure(fig2); subplot(ceil(n_el/4),4,el); cc=jet(n_el);
    hold on
    plot3(IJK(1,:),IJK(2,:),IJK(3,:),'r')
    text(IJK(1,end),IJK(2,end),IJK(3,end),navi_unique{el})
    plot3(VIJK(cidx==el,1),VIJK(cidx==el,2),VIJK(cidx==el,3),'.','Color',cc(el,:));
    plot3(XI,YI,ZI,'c'); title([navi_unique{el} ': trajectory fitting'])
    
    % min distance to target point (směr elktrody od špičce ke konci/naopak)
    [~,mpoz]=min(sqrt(  (XI([1 end])-IJK(1,1)).^2 + (YI([1 end])-IJK(2,1)).^2 + (ZI([1 end])-IJK(3,1)).^2)); % 1- 1:end; 2- end:-1:1
    
    % make electrodes -------------------------------------------------
    [my,mx,mz]=meshgrid(1:size(VCT,2),1:size(VCT,1),1:size(VCT,3));
    
    sigma=eye(3)*el_ball./vox_size;
    
    shift=0:res:3*(el_dist+el_dim);
    CCOR=zeros(length(shift),1);
    CCOR3=zeros(length(shift),1);
    MU=[];
    for s=1:length(shift) 
        fstr=[num2str(el) '/' num2str(n_el) ' ' navi_unique{el,1} ':' num2str(100*s/length(shift),'%0.1f') '%%'];
        fprintf(1,fstr)
        
        
        P=zeros(size(VCT)); % ROI pro genezi elektrod (korálnků)
        
        n_con=navi_unique{el,11};
        mu_idx=zeros(n_con,1); % pro ukládání centroidů kontaktů
        off=0:el_dist+el_dim:(el_dist+el_dim)*(n_con-1); % posuny korálků po šňůrce
        off=off+shift(s);
        
        
        switch mpoz % dle směrů k hrotu/odhrotu
            case 1
                CDL=[0; cumsum(DL)];
                if max(CDL)<max(off); break; end
                for i=1:n_con
                    mu_idx(i)=find(CDL>=off(i),1);
                end
            case 2
                CDL=[0; cumsum(DL(end:-1:1))]; CDL=CDL(end:-1:1);
                if max(CDL)<max(off); break; end
                for i=1:n_con
                    mu_idx(i)=find(CDL<=off(i),1);
                end
        end
        
        
        mu = [XI(mu_idx) YI(mu_idx) ZI(mu_idx)]; % centroidy kontaktů
        MU(:,:,s)=mu; % ukládání po pozdější výběr nejlepšího posunu
        % omezení ROI (VCT, VCTNAV)
        xb=round([min(mu(:,1))-el_ball./vox_size(1), max(mu(:,1))+el_ball./vox_size(1)]); xb(xb<1)=1; xb(xb>size(VCT,1))=size(VCT,1);
        yb=round([min(mu(:,2))-el_ball./vox_size(2), max(mu(:,2))+el_ball./vox_size(2)]); yb(yb<1)=1; yb(yb>size(VCT,2))=size(VCT,2);
        zb=round([min(mu(:,3))-el_ball./vox_size(3), max(mu(:,3))+el_ball./vox_size(3)]); zb(zb<1)=1; zb(zb>size(VCT,3))=size(VCT,3);
        for i=1:n_con
            f= @(x,y,z,mu,sigma) (1/sqrt((2*pi)^3*det(sigma)))*exp(-( ((x-mu(1))/sigma(1,1)).^2+((y-mu(2))/sigma(2,2)).^2 + ((z-mu(3))/sigma(3,3)).^2 ));
            
            P(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2))=P(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2))...
                +f(mx(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2)),my(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2)),mz(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2)),mu(i,:),sigma);
        end
        CCOR(s)=corr(reshape(VCT(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2)).*(VCT(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2))>ct_th),[],1),reshape(P(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2)),[],1));
        
        
        xb=round([min(mu(1:3,1))-el_ball./vox_size(1), max(mu(1:3,1))+el_ball./vox_size(1)]); xb(xb<1)=1; xb(xb>size(VCT,1))=size(VCT,1);
        yb=round([min(mu(1:3,2))-el_ball./vox_size(2), max(mu(1:3,2))+el_ball./vox_size(2)]); yb(yb<1)=1; yb(yb>size(VCT,2))=size(VCT,2);
        zb=round([min(mu(1:3,3))-el_ball./vox_size(3), max(mu(1:3,3))+el_ball./vox_size(3)]); zb(zb<1)=1; zb(zb>size(VCT,3))=size(VCT,3);
        for i=1:3 % první dva kontakty
            f= @(x,y,z,mu,sigma) (1/sqrt((2*pi)^3*det(sigma)))*exp(-( ((x-mu(1))/sigma(1,1)).^2+((y-mu(2))/sigma(2,2)).^2 + ((z-mu(3))/sigma(3,3)).^2 ));
            
            P(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2))=P(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2))...
                +f(mx(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2)),my(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2)),mz(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2)),mu(i,:),sigma);
        end
        CCOR3(s)=corr(reshape(VCT(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2)).*(VCT(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2))>ct_th),[],1),reshape(P(xb(1):xb(2),yb(1):yb(2),zb(1):zb(2)),[],1));
        
        if s<length(shift); fprintf(1,repmat('\b',1,length(fstr)-1)); end
    end
    fprintf(1,'\n')
    kP=1.5;
    PEN=1-kP*(shift/(n_con*el_dim+(n_con-1)*el_dist)); PEN=PEN(:);
    CCOR(isnan(CCOR))=0; CCOR=filtfilt(ones(5,1)/5,1,CCOR); 
    CCOR3(isnan(CCOR3))=0; CCOR3=filtfilt(ones(5,1)/5,1,CCOR3); 
    Csign=ones(size(CCOR));
    Csign(CCOR<0 & CCOR3<0)=-1;
    CCOR_PEN=PEN.*(CCOR.*CCOR3.*Csign)./abs(sqrt(CCOR.*CCOR3));
    [~,lcmax]=max(CCOR_PEN); 
    
    figure(fig3); subplot(ceil(n_el/4),4,el); cla
    plot(shift,CCOR); hold on;
    plot(shift,CCOR3,'r'); plot(shift,PEN,'m')
    plot(shift,CCOR_PEN,'k'); title(navi_unique{el,1}); xlabel('mm')
    plot(shift([lcmax lcmax]),[0 1],':k')
    legend('corr-all','corr-2','penalty','result','MAX','Location','southeast')
    
    
    RES_EL(el).ijk=MU(:,:,lcmax);
    ras=arrayfun(@(x) (ct.mat*[x.ijk ones(size(x.ijk,1),1)]')',RES_EL(el),'UniformOutput',0);
    RES_EL(el).ras=ras{1}(:,1:3);
    
    % plot first contact ===================================================
    first=RES_EL(el).ijk(1,:);
    figure(fig1); 
    hold on; plot3(first(2),first(1),first(3),'or'); %text(first(2),first(1),first(3),navi_unique{el,1},'Color','r')
    for ii=2:size(RES_EL(el).ijk,1)
        plot3(RES_EL(el).ijk(ii,2),RES_EL(el).ijk(ii,1),RES_EL(el).ijk(ii,3),'o','Color',ecc(el,:));
    end
    
    % bone measurement
    if ~emptyNAV
        XI=RES_EL(el).XI;
        YI=RES_EL(el).YI;
        ZI=RES_EL(el).ZI;
        idx=round(ZI)<1 | round(YI)<1 | round(XI)<1;
        XI(idx)=[]; YI(idx)=[]; ZI(idx)=[];
        DL=sqrt(diff(XI(:)*vox_size(1)).^2+diff(YI(:)*vox_size(2)).^2+diff(ZI(:)*vox_size(3)).^2);
        DL=[DL;DL(end)];
        IJK=RES_EL(el).ijk(1,:)'; % first contact
        
        % min. distance to target point (direction from/to the tip)
        [~,mpoz]=min(sqrt(  (XI([1 end])-IJK(1,1)).^2 + (YI([1 end])-IJK(2,1)).^2 + (ZI([1 end])-IJK(3,1)).^2)); % 1- 1:end; 2- end:-1:1
        
        
        XYZ_RAS=ct.mat*[XI YI ZI ones(length(XI),1)]';
        depth=sqrt(sum((XYZ_RAS(1:3,1)'-XYZ_RAS(1:3,:)').^2,2));
        
        smoothR=1; % mm
        mar=round(smoothR/res);
        idx=sub2ind(size(VCTNAV),round(XI),round(YI),round(ZI));
        
        HU=VCTNAV(idx); HU_orig=HU;
        %     HU=filtfilt(ones(mar,1)/mar,1,HU);
        HU=medfilt1(HU,mar);
        
        % 9.11.2021 ---
        head_roi=VCCT(idx);
        dar=round(100/res); if mod(dar,2)==0; dar=dar+1; end
        head_roi=dilateN(head_roi>0,true(dar,1));
        HU(~head_roi)=0;
        %---
        
        boneh=HU>800; % 800 HU cancelous bone
        bonel=HU>300; % 300 HU voids incancelous bone
        re=0.75;
        rdh=20; exh=rdh/res; if mod(exh,2)==0; exh=exh+1; end % 20 mm
        rdl=5; exl=rdl/res; if mod(exl,2)==0; exl=exl+1; end % 5 mm
        boneh=[false(exh,1); boneh; false(exh,1)]; % extension for morphological operation
        M=round(re/res); if mod(M,2)==0; M=M+1; end
        boneh=erodeN(boneh(:),true(M,1));
        M=round(rdh/res); if mod(M,2)==0; M=M+1; end
        boneh=dilateN(boneh(:),true(M,1));
        M=round((rdh-re)/res); if mod(M,2)==0; M=M+1; end
        boneh=erodeN(boneh(:),true(M,1));
        
        bonel=[false(exl,1); bonel; false(exl,1)]; % extension for morphological operation
        M=round(re/res); if mod(M,2)==0; M=M+1; end
        bonel=erodeN(bonel(:),true(M,1));
        M=round(rdl/res); if mod(M,2)==0; M=M+1; end
        bonel=dilateN(bonel(:),true(M,1));
        M=round((rdl-re)/res); if mod(M,2)==0; M=M+1; end
        bonel=erodeN(bonel(:),true(M,1));
        
        bone=boneh(exh+1:end-exh) | bonel(exl+1:end-exl);
        
        
        figure(fig4); subplot(ceil(n_el/4),4,el);
        plot(depth,HU);
        hold on;
        plot(depth,HU_orig,'Color',[.5 .5 .5]);
        plot(depth,VCTNAV(idx),'k');
        plot(depth,800*boneh(exh+1:end-exh),'color',[0.5 0.5 0.5]);
        plot(depth,300*bonel(exl+1:end-exl),'color',[0.75 0.75 0.75]); plot(depth,1000*bone,'r');
        title(navi_unique{el,1}); xlabel('mm'); ylabel('HU')
        
        switch mpoz % dle směrů k hrotu/odhrotu
            case 1
                CDL=[0; cumsum(DL)];
                up=find(diff([0;bone])>0);
                dw=find(diff([bone;0])<0);
                if length(up)>1; [~,mi]=max(abs(diff([up, dw],[],2))); up=up(mi); dw=dw(mi); end
            case 2
                CDL=[0; cumsum(DL(end:-1:1))]; CDL=CDL(end:-1:1);
                bone=bone(end:-1:1);
                up=find(diff([0;bone])>0);
                dw=find(diff([bone;0])<0);
                if length(up)>1; [~,mi]=max(abs(diff([up, dw],[],2))); up=up(mi); dw=dw(mi); end
                %             bonel=bonel(end:-1:1);
                %             boneh=boneh(end:-1:1);
                %             up=find(diff([0;boneh])>0,1);
                %             dw=find(diff([bonel;0])<0); dw(dw<up)=[]; dw=dw(1);
                up=length(bone)-up+1;
                dw=length(bone)-dw+1;
        end
        
        plot(depth([dw up]),[1000 1000],'+-k','LineWidth',2);
        INT=[XI(up) YI(up) ZI(up)];
        EXT=[XI(dw) YI(dw) ZI(dw)];
        
        
        SE=ct.mat*[EXT 1]'-ct.mat*[INT 1]'; SE=SE(1:3)'; SE=SE./sqrt(sum(SE.^2));
        % 1. iterace - gradient dle navigace
        U=EXT-INT;  U=U./sqrt(sum(U.^2)); %U=5*U;
        [~,NS,~,~]=find_angle(ct,vox_size,VCTNAV,EXT,U);
        
        NS=NS./sqrt(sum(NS.^2)); % vektor kolmý na lebku
        %     SE=cell2mat(navi(el,8:10)); % vektor elektrody
        angle_alpha=acosd(SE*(NS(:)));
        if angle_alpha>90; NS=-NS; end
        
        % 2. iterace - gradient dle odhadnuté kolmice
        NS=inv(ct.mat)*[0 0 0 1; NS 1]'; NS=(NS(1:3,2)-NS(1:3,1))';
        %     SE1=inv(ct.mat)*[0 0 0 1; SE 1]'; SE1=SE1(1:3,2)-SE1(1:3,1);
        [plane,NS,XYZ,po]=find_angle(ct,vox_size,VCTNAV,EXT,NS);
        NS=NS./sqrt(sum(NS.^2)); % vektor kolmý na lebku
        angle_alpha=acosd(SE*(NS(:)));
        if angle_alpha>90; NS=-NS; angle_alpha=acosd(SE*(NS(:))); end
        
        % RAS ==============
        EXT=(ct.mat*[EXT 1]')'; EXT=EXT(1:3);
        INT=(ct.mat*[INT 1]')'; INT=INT(1:3);
        
        CENT=EXT-5*NS;
        figure(fig5); subplot(ceil(n_el/4),4,el)
        plot(plane,[XYZ(1,:)',XYZ(2,:)'],XYZ(3,:)'); xlabel('x'); ylabel('y'); zlabel('z'); axis image;
        hold on
        plot3([EXT(po(1)) CENT(po(1))],[EXT(po(2)) CENT(po(2))],[EXT(po(3)) CENT(po(3))],'r')
        plot3([EXT(po(1)) INT(po(1))],[EXT(po(2)) INT(po(2))],[EXT(po(3)) INT(po(3))],'m')
        
        
        [~,e1_poly]=min(sqrt(sum((RES_EL(el).ijk(1,:)-[XI YI ZI]).^2,2)));
        [~,int_poly]=min(sqrt(sum(([XI(up) YI(up) ZI(up)]-[XI YI ZI]).^2,2)));
        IClength=sum(DL(min([e1_poly int_poly]):max([e1_poly int_poly])))+el_dim/2;
        BONElength=sqrt(sum((EXT-INT).^2));
        
        title([navi_unique{el,1} ': ' num2str(90-angle_alpha) ' °'])
        
        U=RES_EL(el).ras(1,:)-RES_EL(el).ras(2,:); U=U./sqrt(sum(U.^2));
        TIP=RES_EL(el).ras(1,:)+U*el_dim/2;
        
        % RES(el+1,:)=[navi_unique(el,1) num2cell(TIP) num2cell(INT) num2cell(EXT) {90-angle_alpha,IClength,BONElength} navi_unique(el,11) navi_unique(el,12)];
        BONE_MEASURE.Name(el)=navi.Name(el);
        BONE_MEASURE.("Bone thickness")(el)=BONElength;
        BONE_MEASURE.("Implant. angle")(el)=90-angle_alpha;
        BONE_MEASURE.("Depth from ENTintra")(el)=IClength;
        BONE_MEASURE.TIP{el}=TIP;
        BONE_MEASURE.ENTextra{el}=EXT;
        BONE_MEASURE.ENTintra{el}=INT;

        figure(fig4)
        figure(fig4); subplot(ceil(n_el/4),4,el);
        title([navi_unique{el,1} ': ' num2str(BONElength,'%.1f') ' mm'])
    end
end

save(fullfile(CTE.dir,'navi_electrode_models.mat'),'GMM','RES_EL','navi_unique')

% full montage list
EL_SET={};
for el=1:n_el
    prefix=navi_unique{el,1};
    sufix=(1:size(RES_EL(el).ras,1))';
    
    elname=arrayfun(@(x) [prefix num2str(x)],sufix,'UniformOutput',0);
    
    EL_SET=[EL_SET; [elname num2cell(RES_EL(el).ras)]];
end

montage2fcsv_v2(EL_SET, [MR.dir 'SLICER' filesep 'electrodes_auto.fcsv'],'ras',[])


dot=strfind(elset_path,'.');
format=elset_path(dot(end)+1:end);
switch format
    case {'csv','CSV'}
        writecell(EL_SET,elset_path,'Delimiter',';');
        if ~isempty(BONE_MEASURE)
            writetable(BONE_MEASURE,bone_path,'Delimiter',';');
        end
end

fprintf(2,['Coordinates saved to: \n'])
disp(elset_path)
if ~isempty(BONE_MEASURE)
    fprintf(2,['Bone measurement saved to: \n'])
    disp(bone_path)
end
end




function [plane,NS,XYZ,po]=find_angle(ct,vox_size,VCTNAV,EXT,U)


ball=10; % mm
[MASK,~] = morphological_mask(ball, vox_size,'ball');
ms=size(MASK);
% ROI=VCTNAV(round(EXT(1))-floor(ms(1)/2):round(EXT(1))+floor(ms(1)/2),...
%     round(EXT(2))-floor(ms(2)/2):round(EXT(2))+floor(ms(2)/2),...
%     round(EXT(3))-floor(ms(3)/2):round(EXT(3))+floor(ms(3)/2));
roilim=[round(EXT(1))-floor(ms(1)/2);round(EXT(2))-floor(ms(2)/2);round(EXT(3))-floor(ms(3)/2);round(EXT(1))+floor(ms(1)/2);round(EXT(2))+floor(ms(2)/2);round(EXT(3))+floor(ms(3)/2)];

addzeros=zeros(6,1);
addzeros(1:3)=(1-roilim(1:3)).*((1-roilim(1:3))>=0);
addzeros(4:6)=(roilim(4:6)-size(VCTNAV)').*((roilim(4:6)-size(VCTNAV)')>0);

roilim([roilim(1:3)<1; false(3,1)])=1;
msize=size(VCTNAV)';
roilim([false(3,1); roilim(4:6)>msize])=msize(roilim(4:6)>msize);

ROI=VCTNAV(roilim(1):roilim(4),roilim(2):roilim(5),roilim(3):roilim(6));
msize=size(ROI)';
ROI=[zeros(addzeros(1),msize(2),msize(3)); ROI];
ROI=[zeros(msize(1),addzeros(2),msize(3)), ROI];
ROI=cat(3,zeros(msize(1),msize(2),addzeros(3)), ROI);

ROI=[ROI; zeros(addzeros(4),msize(2),msize(3))];
ROI=[ROI, zeros(msize(1),addzeros(5),msize(3))];
ROI=cat(3, ROI, zeros(msize(1),msize(2),addzeros(6)));

ROI=ROI>400;
EXROI=false(2*size(MASK,1)+size(ROI,1),2*size(MASK,3)+size(ROI,3),2*size(MASK,3)+size(ROI,3));
EXROI(size(MASK,1)+1:size(MASK,1)+size(ROI,1),size(MASK,2)+1:size(MASK,2)+size(ROI,2),size(MASK,3)+1:size(MASK,3)+size(ROI,3))=ROI;
EXROI=dilateN(EXROI,MASK);
EXROI=erodeN(EXROI,MASK);
ROI=EXROI(size(MASK,1)+1:size(MASK,1)+size(ROI,1),size(MASK,2)+1:size(MASK,2)+size(ROI,2),size(MASK,3)+1:size(MASK,3)+size(ROI,3));
ROI=ROI.*MASK;


[my,mx,mz]=meshgrid(-2:2,-2:2,-2:2);
grad=reshape([mx(:) my(:) mz(:)]*U',size(my)); grad=grad/sum(abs(grad(:))); % směrová diferenciace
DROI=convn(ROI,grad,'same'); % mapa gradientů přechodu kůže/kost
MDROI=(DROI>(max(DROI(:))/2)); % polovina maxima k detekci

idx=find(MDROI); [x,y,z]=ind2sub(size(MDROI),idx);
% idx to ras
x=x+round(EXT(1))-floor(ms(1)/2)-1;
y=y+round(EXT(2))-floor(ms(2)/2)-1;
z=z+round(EXT(3))-floor(ms(3)/2)-1;
XYZ=ct.mat*[x y z ones(length(x),1)]';


[plane1,gof1] = fit([XYZ(1,:)',XYZ(2,:)'],XYZ(3,:)','poly11');
[plane2,gof2] = fit([XYZ(3,:)',XYZ(2,:)'],XYZ(1,:)','poly11');
[plane3,gof3] = fit([XYZ(1,:)',XYZ(3,:)'],XYZ(2,:)','poly11');
[~,pmin]=min([gof1.rmse gof2.rmse gof3.rmse]);
switch pmin
    case 1
        plane=plane1;
        NS=[plane.p10 plane.p01 -1]; % normálový vektor roviny n1x+n2y+n3z+d=0;
        po=[1 2 3];
    case 2
        plane=plane2;
        NS=[-1 plane.p01 plane.p10]; % normálový vektor roviny n1x+n2y+n3z+d=0;
        XYZ=XYZ([3 2 1 4],:); po=[3 2 1];
    case 3
        plane=plane3;
        NS=[plane.p10 -1 plane.p01];
        XYZ=XYZ([1 3 2 4],:); po=[1 3 2];
end


end







