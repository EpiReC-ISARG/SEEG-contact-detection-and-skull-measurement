function originator_reset_v2(INVOL)

% INVOL = [CT;OTHER;PET];
disp('')
disp('------------------------------------------------')
disp('NIFTI check, ORIGIN reset')
disp('------------------------------------------------')
disp('')

if iscell(INVOL)
    INVOL=stringpath2struct(INVOL);
end


for i=1:length(INVOL)
    if isempty(INVOL(i).path); continue; end
    
    disp(INVOL(i).name)
    V1 = spm_vol(INVOL(i).path);
    qter=spm_imatrix(V1.mat);
    
    dir_cos=spm_matrix([0 0 0 qter(4:6)]);
    pix_dim=qter(7:9);
    
    orig_old=qter(1:3);
    orig_new=(V1.dim(:)/2).*(pix_dim(:));
    orig_new=-dir_cos*[orig_new(:); 1]; orig_new(4)=[];
    
    T=spm_matrix([orig_new(:)' qter(4:end-3) qter(10:12)]);
    V1.mat=T;
    V1.private.mat=T;
    V1.private.mat0=T;
    V1 = spm_create_vol(V1);
    
    % nan removing
    VOL=spm_read_vols(V1);
    VOL(isnan(VOL))=nanmin(VOL(:));
    spm_write_vol(V1,VOL);
end
end





function OUT=stringpath2struct(IN)

if iscell(IN)
    NEWstruct=[];
    for i=1:length(IN)
        name=dir(IN{i});
        NEWstruct(i).path=fullfile(name.folder,name.name);
        NEWstruct(i).dir=name.folder;
        
        sidx=sort([strfind(name.name,'/') strfind(name.name,'\')]);
        if isempty(sidx)
            NEWstruct(i).name=name.name;
        else
            NEWstruct(i).name=name.name(sidx(end)+1:end);
        end
    end
    OUT=NEWstruct;
elseif isstruct(IN) || isempty(IN)
    OUT=IN;
else
    error('incorrect input (path or struct)')
end


end